import UIKit
import WebKit

class WebViewCoordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler, WKDownloadDelegate {
    var parent: WebView
    var hasLoaded = false
    weak var webView: WKWebView?

    init(_ parent: WebView) {
        self.parent = parent
        super.init()
    }

    // MARK: - JavaScript Message Handling
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "shareDetails" {
            if let dict = message.body as? [String: String],
               let name = dict["name"],
               let designation = dict["designation"],
               let phone = dict["phone"] {
                shareDetails(name: name, designation: designation, phone: phone)
            }
        }

        if message.name == "getNumber" {
            getPhoneNumber()
        }
    }

    private func shareDetails(name: String, designation: String, phone: String) {
        let shareText = "Name: \(name)\nDesignation: \(designation)\nPhone: \(phone)"
        let av = UIActivityViewController(activityItems: [shareText], applicationActivities: nil)
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first,
           let vc = window.rootViewController {
            av.popoverPresentationController?.sourceView = vc.view
            vc.present(av, animated: true)
        }
    }

    private func getPhoneNumber() {
        // Placeholder for getPhoneNumber logic
    }

    // MARK: - Navigation
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        parent.isLoading = true
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        parent.isLoading = false
        webView.scrollView.refreshControl?.endRefreshing()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        parent.isLoading = false
        webView.scrollView.refreshControl?.endRefreshing()
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }

        if navigationAction.navigationType == .linkActivated,
           !url.absoluteString.starts(with: "https://mahasampark.in") {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }

        decisionHandler(.allow)
    }

    // MARK: - Refresh
    @objc func refresh(_ sender: UIRefreshControl) {
        webView?.reload()
        sender.endRefreshing()
        hasLoaded = true
    }

    // MARK: - WKDownloadDelegate (iOS 14+)
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationURL = documentsPath.appendingPathComponent(suggestedFilename)
        print("📥 Saving to: \(destinationURL.path)")
        completionHandler(destinationURL)
    }

    func download(_ download: WKDownload, didFinishWithError error: Error?) {
        if let error = error {
            print("❌ Download failed: \(error.localizedDescription)")
        } else {
            print("✅ Download finished successfully")
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: NSNotification.Name("DownloadComplete"), object: nil)
            }
        }
    }
}
